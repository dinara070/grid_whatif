"""gridcore - обчислювальне ядро цифрового двійника мережі 10 кВ (Вінницька область).

Шари (без залежності від Streamlit):
    model       топологія, параметри режиму, профілі
    powerflow   pandapower: режими, відновлення живлення, N-1/N-k
    protection  струми КЗ і уставки РЗА
    forecast    ML-прогноз навантаження (Open-Meteo), огляд області
    predictive  прогноз відмов, SHAP, ризик
    telemetry   потік телеметрії (симулятор / MQTT);  simulator - сам генератор
    viz         plotly/matplotlib-фігури
    report      PDF-звіт
    service     фасад для UI та API
Пакет навмисно не імпортує важкі залежності в __init__, щоб simulator/model були легкими.
"""
