"""Тести обчислювального ядра та API: працюють БЕЗ Streamlit (доказ розділення логіки та UI).

Запуск:  pytest -q
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
sys.modules["streamlit"] = None        # будь-який імпорт streamlit у ядрі одразу впаде

import pytest                                              # noqa: E402

from gridcore import service                               # noqa: E402
from gridcore.model import ALL_ELEMS, DISTRICTS, NODES, Params, build_grid, make_params   # noqa: E402
from gridcore.powerflow import health_check, solve_c       # noqa: E402
from gridcore.simulator import Simulator                   # noqa: E402


def test_grid_is_deterministic():
    n1, e1 = build_grid()
    n2, e2 = build_grid()
    assert n1 == n2 and e1 == e2
    assert len(ALL_ELEMS) == 42 and len(DISTRICTS) == 8
    assert all("ctype" in d for d in NODES.values())


def test_make_params_roundtrip():
    P = make_params(temp=-15, hour=7)
    assert len(P) == len(Params._fields) and hash(P)
    assert Params(*P).temp == -15.0 and Params(*P).prof == ()


def test_power_flow_converges():
    ok, err = health_check(Params(*make_params()))
    assert ok, err


def test_n1_scenario_restores_via_tie():
    res = solve_c(make_params(), ("ТП-103",))
    s = service.summarize_scenario(res)
    assert s["metrics"]["unsupplied_mw"] < 0.6
    assert any(st["type"] == "close" for st in s["steps"])
    assert s["metrics"]["violations"] == 0


def test_validate_elements():
    with pytest.raises(ValueError):
        service.validate_elements(["ТП-999"])


def test_simulator_matches_model():
    msgs = Simulator(seed=1).tick()
    assert {m["asset"] for m in msgs} == {n for n in NODES}
    assert all(m["oil_c"] > -50 for m in msgs)


def test_pdf_report_basic():
    pdf = service.build_pdf(make_params(), ("ТП-103",), "Вінниця", include_risk=False)
    assert pdf.startswith(b"%PDF") and len(pdf) > 50_000


def test_api_endpoints():
    from fastapi.testclient import TestClient
    import api
    c = TestClient(api.app)
    assert c.get("/health").json()["status"] == "ok"
    assert len(c.get("/grid").json()["nodes"]) == 22
    r = c.post("/scenario", json={"elements": ["ТП-103"]})
    assert r.status_code == 200 and r.json()["metrics"]["violations"] == 0
    assert c.post("/scenario", json={"elements": ["ТП-999"]}).status_code == 422
    r = c.post("/report/pdf", json={"elements": ["ТП-103"], "include_risk": False})
    assert r.status_code == 200 and r.headers["content-type"] == "application/pdf" and r.content[:4] == b"%PDF"
